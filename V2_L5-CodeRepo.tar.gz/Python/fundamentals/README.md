Location for fundamentals scripts
